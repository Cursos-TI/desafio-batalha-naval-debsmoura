
# 🛳️ Desafio Batalha Naval - Nível Novato

Este projeto simula o posicionamento de dois navios em um tabuleiro de Batalha Naval utilizando vetores bidimensionais em linguagem C.

## 🎯 Objetivos

- Posicionar dois navios no tabuleiro:
  - Um na **vertical** com tamanho 3;
  - Um na **horizontal** com tamanho 4.
- Utilizar **vetores bidimensionais** para representar o tabuleiro.
- Exibir as **coordenadas** das partes dos navios com `printf`.

## 📥 Entrada de Dados

- As coordenadas dos navios são inseridas diretamente no código, por meio de variáveis.

## 📤 Saída de Dados

- Após o posicionamento, o programa imprime no console as coordenadas ocupadas por cada navio de forma clara e organizada.

## 🚀 Como executar

Compile com:

```bash
gcc batalha_naval.c -o batalha_naval
./batalha_naval
```
